
namespace ErrorHandling.Task1.ThirdParty
{
    public interface IOrder
    {
        double Total();
        bool IsSubmitted();
    }
}
