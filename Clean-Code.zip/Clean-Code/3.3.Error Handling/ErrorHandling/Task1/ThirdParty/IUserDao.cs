namespace ErrorHandling.Task1.ThirdParty
{
    public interface IUserDao
    {
        IUser GetUser(string userId);
    }
}
