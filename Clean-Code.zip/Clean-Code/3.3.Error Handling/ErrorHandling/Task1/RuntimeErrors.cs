﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ErrorHandling.Task1
{
    public class RuntimeErrors : Exception
    {
        public ErrorCodes errorCode { get; }
        public string errorMessage { get; }

        public RuntimeErrors(ErrorCodes errorCode)
        {
            this.errorCode = errorCode;
        }

        public RuntimeErrors()
        {

        }
        public RuntimeErrors(string message)
            : base(message)
        {
        }

        public RuntimeErrors(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}