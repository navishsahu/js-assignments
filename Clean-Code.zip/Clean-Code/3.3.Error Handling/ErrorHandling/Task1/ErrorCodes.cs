﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ErrorHandling.Task1
{
    public enum ErrorCodes
    {
        GenericError = 0,
        UserNotFound = -1,
        OrderNotFound = -2,
        InvalidOrderAmount = -3,
        NullValue = -4
    }
}
