﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ErrorHandling.Task1
{
    public class ErrorMessages
    {
        private static readonly Dictionary<ErrorCodes, string> _errorCodesWithMessages = new Dictionary<ErrorCodes, string>();

        static ErrorMessages()
        {
            _errorCodesWithMessages.Add(ErrorCodes.UserNotFound, "WARNING: User ID doesn't exist.");
            _errorCodesWithMessages.Add(ErrorCodes.OrderNotFound, "WARNING: User have no submitted orders.");
            _errorCodesWithMessages.Add(ErrorCodes.InvalidOrderAmount, "ERROR: Wrong order amount.");
            _errorCodesWithMessages.Add(ErrorCodes.GenericError, "technicalError");
            _errorCodesWithMessages.Add(ErrorCodes.NullValue, "Object is null or undefined");
        }

        public static string GetMessageByCode(ErrorCodes errorCode)
        {
            return _errorCodesWithMessages.GetValueOrDefault(errorCode);
        }
    }
}