using System.Collections.Generic;
using System;
using ErrorHandling.Task1.ThirdParty;

namespace ErrorHandling.Task1
{
    public class UserReportBuilder
    {
        private IUserDao userDao;

        public double GetUserTotalOrderAmount(string userId)
        {
            IUser user = GetUser(userId);
            IList<IOrder> orders = GetOrders(user);
            double sum = CalculateTotalAmountOfSubmittedOrders(orders);
            return sum;
        }

        private IUser GetUser(string userId)
        {
            IUser user = userDao.GetUser(userId);
            if (user == null)
            {
                throw new RuntimeErrors(ErrorCodes.UserNotFound);
            }

            return user;
        }

        private static IList<IOrder> GetOrders(IUser user)
        {
            IList<IOrder> orders = user.GetAllOrders();
            if (orders.Count == 0)
            {
                throw new RuntimeErrors(ErrorCodes.OrderNotFound);
            }
            return orders;
        }


        private double CalculateTotalAmountOfSubmittedOrders(IList<IOrder> orders)
        {
            double sum = 0.0;
            foreach (IOrder order in orders)
            {
                if (order.IsSubmitted())
                {
                    double total = order.Total();
                    if (total < 0)
                    {
                        throw new RuntimeErrors(ErrorCodes.InvalidOrderAmount);
                    }

                    sum += total;
                }
            }

            return sum;
        }


        public IUserDao GetUserDao()
        {
            if (userDao == null)
            {
                throw new RuntimeErrors(ErrorCodes.NullValue);
            }
            return userDao;
        }

        public void SetUserDao(IUserDao userDao)
        {
            this.userDao = userDao;
        }

    }
}
