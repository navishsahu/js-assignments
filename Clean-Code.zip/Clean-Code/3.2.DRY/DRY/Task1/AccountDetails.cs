﻿using System;

namespace DRY.Task1.ThirdParty
{
    public class AccountDetails
    {
        public DateTime dateOfBirth { get; set; }
        public int age { get; set; }
        public decimal balance { get; set; }
        public DateTime startDate { get; set; }
    }
}
