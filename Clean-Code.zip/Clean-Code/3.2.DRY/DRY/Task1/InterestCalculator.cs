﻿using System;
using System.Globalization;
using DRY.Task1.ThirdParty;

namespace DRY.Task1
{
    public class InterestCalculator
    {
        private const int maxAge = 60;
        private const double interestPercent = 4.5d;
        private const double seniorPercent = 5.5d;
        private const int bonusAge = 13;

        public decimal CalculateInterest(AccountDetails accountDetails)
        {
            if (IsAccountStartedAfterBonusAge(accountDetails))
            {
                return Interest(accountDetails);
            }

            return 0;
        }

        private bool IsAccountStartedAfterBonusAge(AccountDetails accountDetails)
        {
            return DurationBetweenDatesInYears(accountDetails.dateOfBirth, accountDetails.startDate) > bonusAge;
        }

        private int DurationBetweenDatesInYears(DateTime fromDate, DateTime toDate)
        {
            Calendar calendar = new GregorianCalendar();
            int diffYear = calendar.GetYear(toDate) - calendar.GetYear(fromDate);
            if (calendar.GetDayOfYear(toDate) < calendar.GetDayOfYear(fromDate))
                return diffYear - 1;
            return diffYear;
        }

        private decimal Interest(AccountDetails accountDetails)
        {
            if (IsAccountStartedAfterBonusAge(accountDetails))
            {
                if (maxAge <= accountDetails.age)
                    return GetInterest(accountDetails, interestPercent);
                else
                    return GetInterest(accountDetails, seniorPercent);
            }

            return 0;
        }

        private decimal GetInterest(AccountDetails accountDetails, double percent)
        {
            return Convert.ToDecimal(Convert.ToDouble(accountDetails.balance) * DurationSinceStartDateInYears(accountDetails.startDate) * percent / 100);
        }

        private double DurationSinceStartDateInYears(DateTime startDate)
        {
            return DurationBetweenDatesInYears(startDate, DateTime.Now);
        }
    }
}
