﻿namespace Complex.Task1.ThirdParty
{
    public interface IView
    {
        void Write(string message);

        string Read();
    }
}
