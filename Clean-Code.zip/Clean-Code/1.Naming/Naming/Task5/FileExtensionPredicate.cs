﻿using System.Linq;
using Naming.Task5.ThirdParty;

namespace Naming.Task5
{
    public class FileExtensionPredicate : IPredicate<string>
    {
        private readonly string[] fileExtensions;

        public FileExtensionPredicate(string[] fileExtensions)
        {
            this.fileExtensions = fileExtensions;
        }

        public bool IsValidFile(string fileName)
        {
            fileName = fileName.ToLower();
            return fileExtensions.Any(fileName.EndsWith);
        }
    }
}
