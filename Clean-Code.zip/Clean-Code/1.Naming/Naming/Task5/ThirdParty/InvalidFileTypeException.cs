﻿using System;

namespace Naming.Task5.ThirdParty
{
    public class InvalidFileTypeException : Exception
    {
    }
}
