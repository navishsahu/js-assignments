﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.FileProviders;
using Naming.Task5.ThirdParty;

namespace Naming.Task5
{
    public class FileManager
    {
        private static readonly string[] IMAGETYPES = {"jpg", "png"};
        private static readonly string[] DOCUMENTTYPES = {"pdf", "doc"};

        private const string fileSource = "Naming.Resources";
        private readonly IFileProvider fileProvider = new EmbeddedFileProvider(Assembly.GetExecutingAssembly(), fileSource);

        public IFileInfo RetrieveFile(string fileName)
        {
            ValidateFileType(fileName);
            return fileProvider.GetFileInfo(fileName);
        }

        #region RetrieveFile

        private static void ValidateFileType(string fileName)
        {
            if (IsInValidFileType(fileName))
            {
                throw new InvalidFileTypeException();
            }
        }

        private static bool IsInValidFileType(string fileName)
        {
            return IsInValidImage(fileName) && IsInValidDocument(fileName);
        }

        private static bool IsInValidImage(string fileName)
        {
            var imageExtensionsPredicate = new FileExtensionPredicate(IMAGETYPES);
            return !imageExtensionsPredicate.IsValidFile(fileName);
        }

        private static bool IsInValidDocument(string fileName)
        {
            var documentExtensionsPredicate = new FileExtensionPredicate(DOCUMENTTYPES);
            return !documentExtensionsPredicate.IsValidFile(fileName);
        }

        #endregion

        public List<string> ListAllImages()
        {
            return Files(IMAGETYPES);
        }

        public List<string> ListAllDocuments()
        {
            return Files(DOCUMENTTYPES);
        }

        private List<string> Files(string[] allowedExtensions)
        {
            var predicate = new FileExtensionPredicate(allowedExtensions);
            return fileProvider.GetDirectoryContents(string.Empty)
                .Select(f => f.Name)
                .Where(predicate.IsValidFile)
                .ToList();
        }
    }
}
