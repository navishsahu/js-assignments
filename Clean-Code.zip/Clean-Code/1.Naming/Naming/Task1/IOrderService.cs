﻿using Naming.Task1.ThirdParty;

namespace Naming.Task1
{
    public interface IOrderService
    {
        void SubmitOrder(IOrder order);
    }
}
