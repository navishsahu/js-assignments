﻿namespace Naming.Task1.ThirdParty
{
    public interface IDeliveryService
    {
        bool IsDeliverable();
    }
}
