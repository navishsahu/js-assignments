﻿namespace Naming.Task1.ThirdParty
{
    public enum Message
    {
        ImpossibleToCollect,
        ReadyForCollect
    }
}
