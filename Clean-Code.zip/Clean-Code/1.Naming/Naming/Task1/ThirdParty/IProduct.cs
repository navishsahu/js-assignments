﻿namespace Naming.Task1.ThirdParty
{
    public interface IProduct
    {
    }
}
