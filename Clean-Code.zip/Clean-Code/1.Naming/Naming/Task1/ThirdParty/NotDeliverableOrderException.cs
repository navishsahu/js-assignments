﻿using System;

namespace Naming.Task1.ThirdParty
{
    public class NotDeliverableOrderException : Exception
    {
    }
}
