﻿namespace Naming.Task1.ThirdParty
{
    public interface INotificationManager
    {
        void NotifyCustomer(Message message, int level);
    }
}
