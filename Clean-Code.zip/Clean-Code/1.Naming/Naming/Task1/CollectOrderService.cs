﻿using Naming.Task1.ThirdParty;

namespace Naming.Task1
{
    public class CollectOrderService : IOrderService
    {
        private readonly ICollectionService collectionService;
        private readonly INotificationManager notificationManager;

        public CollectOrderService(ICollectionService collectionService, INotificationManager cotificationManager)
        {
            this.collectionService = collectionService;
            this.notificationManager = cotificationManager;
        }

        public void SubmitOrder(IOrder order)
        {
            if (collectionService.IsEligibleForCollect(order))
            {
                notificationManager.NotifyCustomer(Message.ReadyForCollect, 4); // 4 - info notification level
            }
            else
            {
                notificationManager.NotifyCustomer(Message.ImpossibleToCollect, 1); // 1 - critical notification level
            }
        }
    }
}
