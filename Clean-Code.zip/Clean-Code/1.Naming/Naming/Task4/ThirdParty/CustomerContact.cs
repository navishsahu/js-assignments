﻿namespace Naming.Task4.ThirdParty
{
    public class CustomerContact
    {
        public float CustomerId { get; set; }
        public string EmailId { get; set; }
        public float ContactNumber { get; set; }
        public float AlternateNumber { get; set; }
    }
}
