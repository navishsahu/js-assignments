﻿using System;
using System.Linq;

namespace Naming.Task6
{
    public static class Formatter
    {
        private const string plus = "+";
        private const string pipe = "|";
        private const string minus = "-";
        private const string underscore = "_";

        public static void Main(string[] args)
        {
            Console.WriteLine(FormatKeyValue("enable", "true"));
            Console.WriteLine(FormatKeyValue("name", "Bob"));

            Console.Write("Press key...");
            Console.ReadKey();
        }

        private static string FormatKeyValue(string key, string value)
        {
            string content = key + underscore + value;
            string minuses = Repeat(minus, content.Length);
            return plus + minuses + plus + "\n" +
                   pipe + content + pipe + "\n" +
                   plus + minuses + plus + "\n";
        }

        private static string Repeat(string symbol, int times)
        {
            return string.Join(string.Empty, Enumerable.Repeat(symbol, times));
        }
    }
}
