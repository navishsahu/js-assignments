﻿namespace Functions.Task4.Stubs
{
    public class AvailableProductStub : AbstractProductStub
    {
        public override bool IsAvailable()
        {
            return true;
        }
    }
}