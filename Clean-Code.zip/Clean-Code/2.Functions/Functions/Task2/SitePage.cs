﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Functions.Task2
{
    public class SitePage
    {
        private const string http = "http://";
        private const string editable = "/?edit=true";
        private const string domain = "mysite.com";

        public string siteGroup { get; }
        public string userGroup { get; }

        public SitePage(string siteGroup, string userGroup)
        {
            this.siteGroup = siteGroup;
            this.userGroup = userGroup;
        }

        public string GetEditablePageUrl(IDictionary<string, string> parameters)
        {
            return GetURL(parameters); 
        }

        private string GetURL(IDictionary<string, string> parameters)
        {
            return http + domain + editable + GetParameters(parameters) + GetAttributes();
        }

        private string GetParameters(IDictionary<string, string> parameters)
        {
            var paramsString = new StringBuilder();
            foreach (var parameter in parameters)
            {
                paramsString.Append($"&{parameter.Key}={parameter.Value}");
            }
            return paramsString.ToString();
        }

        private string GetAttributes()
        {
            return $"&siteGrp={siteGroup}&userGrp={userGroup}";
        }
    }
}