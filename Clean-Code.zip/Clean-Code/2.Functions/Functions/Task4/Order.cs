﻿using System;
using System.Collections.Generic;
using System.Linq;
using Functions.Task4.ThirdParty;

namespace Functions.Task4
{
    public class Order
    {
        public IList<IProduct> products { get; set; }

        public double GetPriceOfAvailableProducts()
        {
            IEnumerator<IProduct> enumerator = products.ToList().GetEnumerator();

            GetAvailableProducts(enumerator);
            
            return GetPrice();
        }

        private double GetPrice()
        {
            var orderPrice = 0.0;
            foreach (IProduct product in products)
            {
                orderPrice += product.GetProductPrice();
            }
            return orderPrice;
        }

        private void GetAvailableProducts(IEnumerator<IProduct> enumerator)
        {
            while (enumerator.MoveNext())
            {
                IProduct product = enumerator.Current;
                if (!product.IsAvailable())
                {
                    products.Remove(product);
                }
            }
        }
    }
}
