﻿namespace Functions.Task4.ThirdParty
{
    public interface IProduct
    {
        double GetProductPrice();

        bool IsAvailable();
    }
}