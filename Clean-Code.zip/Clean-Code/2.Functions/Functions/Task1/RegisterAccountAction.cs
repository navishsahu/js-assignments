﻿using Functions.Task1.ThirdParty;
using System;
using System.Collections.Generic;

namespace Functions.Task1
{
    public class RegisterAccountAction
    {
        public IPasswordChecker passwordChecker { get; set; }
        public IAccountManager accountManager { get; set; }

        public void RegisterAccount(IAccount account)
        {
            ValidateUserName(account);

            ValidatePassword(account);

            account.SetCreatedDate(new DateTime());
            List<IAddress> addresses = new List<IAddress>
            {
                account.GetHomeAddress(),
                account.GetWorkAddress(),
                account.GetAdditionalAddress()
            };
            account.SetAddresses(addresses);
            accountManager.CreateNewAccount(account);
        }

        private void ValidatePassword(IAccount account)
        {
            string password = account.GetPassword();

            if (password.Length <= 8)
            {
                if (passwordChecker.Validate(password) != CheckStatus.Ok)
                {
                    throw new WrongPasswordException();
                }
            }
        }

        private void ValidateUserName(IAccount account)
        {
            if (account.GetName().Length <= 5)
            {
                throw new WrongAccountNameException();
            }
        }
    }
}