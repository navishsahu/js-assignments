﻿using System;

namespace Functions.Task1.ThirdParty
{
    [Serializable]
    public class WrongPasswordException : Exception
    {
    }
}