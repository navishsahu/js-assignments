﻿namespace Functions.Task1.ThirdParty
{
    public interface IAddress
    {
    }
}