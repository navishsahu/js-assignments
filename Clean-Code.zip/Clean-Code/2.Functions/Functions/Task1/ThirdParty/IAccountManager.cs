﻿namespace Functions.Task1.ThirdParty
{
    public interface IAccountManager
    {
        void CreateNewAccount(IAccount account);
    }
}