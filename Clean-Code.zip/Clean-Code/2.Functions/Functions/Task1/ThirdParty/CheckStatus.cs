﻿namespace Functions.Task1.ThirdParty
{
    public enum CheckStatus
    {
        Ok,
        Warning,
        Wrong
    }
}
