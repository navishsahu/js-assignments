﻿namespace Functions.Task3.ThirdParty
{
    public interface ISessionManager
    {
        void SetCurrentUser(IUser user);
    }
}