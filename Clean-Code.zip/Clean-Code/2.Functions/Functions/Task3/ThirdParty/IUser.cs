﻿namespace Functions.Task3.ThirdParty
{
    public interface IUser
    {
    }
}