﻿/* CODE COMPILED AND RUN FROM TRAIN SECTION OF CODEWAR */

//JAVASCRIPT DATA TYPES

//Printing Array elements with Comma delimiters
function printArray(array) {
    let arr = [];
    for (var str in array) {
        arr.push(array[str]);
    }
    return arr;
}

//Opposite number
function opposite(number) {
    return -number;
}

//Basic Mathematical Operations
function basicOp(operation, value1, value2) {
    if (operation === '+')
        return value1 + value2;
    else if (operation === '-')
        return value1 - value2;
    else if (operation === '*')
        return value1 * value2;
    else if (operation === '/')
        return value1 / value2;
}

//Transportation on vacation 
function rentalCarCost(d) {
    let day = d >= 3 && d < 7 ? 20 : 0, // day discount
        week = d >= 7 ? 50 : 0; // week discount

    return ((d * 40) - day - week);
}

//FUNCTIONS & SCOPE

//Calculating with Functions
function zero() { return arguments.length === 1 ? arguments[0](0) : 0; }
function one() { return arguments.length === 1 ? arguments[0](1) : 1; }
function two() { return arguments.length === 1 ? arguments[0](2) : 2; }
function three() { return arguments.length === 1 ? arguments[0](3) : 3; }
function four() { return arguments.length === 1 ? arguments[0](4) : 4; }
function five() { return arguments.length === 1 ? arguments[0](5) : 5; }
function six() { return arguments.length === 1 ? arguments[0](6) : 6; }
function seven() { return arguments.length === 1 ? arguments[0](7) : 7; }
function eight() { return arguments.length === 1 ? arguments[0](8) : 8; }
function nine() { return arguments.length === 1 ? arguments[0](9) : 9; }

function plus() {
    var val = arguments[0];
    return function (left) {
        return (left + val);
    }
}
function minus() {
    var val = arguments[0];
    return function (left) {
        return (left - val);
    }
}
function times() {
    var val = arguments[0];
    return function (left) {
        return (left * val);
    }
}
function dividedBy() {
    var val = arguments[0];
    return function (left) {
        return Math.floor(left / val);
    }
}

//Get the Middle Character
function getMiddle(s) {
    return s.substr(s.length - 1 >>> 1, (~s.length & 1) + 1);
}

//Alternate solution
function getMiddleChars(s) {
    return s.length % 2 ? s.substr(s.length / 2, 1) : s.substr((s.length / 2) - 1, 2);
}

//Partition On
// partition the items array so that all values for which pred returns true are at the end, returning the index of the first true value
function partitionOn(pred, items) {
    var truthies = items.filter(pred);
    var falsies = items.filter(function (a) { return !pred(a) });
    items.length = 0; items.push.apply(items, falsies.concat(truthies));
    return falsies.length;
}

//Word Count
function countWords(str) {
    var matches = str.match(/[\w\d’'-]+/gi);
    return matches ? matches.length : 0;
}

//DYNAMIC SCOPE

//Prefill an Array
function prefill(n, v) {
    if (/\D/g.test(n) || n < 0) {
        throw new TypeError(n + ' is invalid')
    }
    return Array.apply(null, new Array(parseInt(n, 10))).map(function () {
        return v;
    });
}

//Closures and Scopes
function createFunctions(n) {
    var callbacks = [];
    function handle(j) {
        return function () {
            return j;
        }
    };
    for (var i = 0; i < n; i++) {
        callbacks.push(handle(i));
    }
    return callbacks;
}

//Can you keep a secret?
function createSecretHolder(secret) {
    var _secret = secret;
    return {
        setSecret: function (s) {
            _secret = s;
        },
        getSecret: function () {
            return _secret;
        }
    };
}

//A function within a function
// return a function that returns n
function always(n) {
    return function () {
        return n;
    }
}

//OBJECTS and ARRAYS

//Using closures to share class state
// Let's make a Cat constructor!
var Cat = (function () {
    var catCount = 0, catAggWeight = 0;
    var constr = function (name, weight) {
        if (!name || !weight) {
            throw 'Must provide a name and a weight!';
        }
        catCount++;
        catAggWeight += weight;
        Object.defineProperty(this, 'weight', {
            set: function (v) {
                catAggWeight += v - weight;
                weight = v;
            },
            get: function () {
                return weight;
            }
        });
    }
    constr.averageWeight = function () {
        return catAggWeight / catCount;
    }
    return constr;
}());

//A Chain adding function
function add(n) {
    var sum = n;
    const proxy = new Proxy(function a() { }, {
        get(obj, key) {
            return () => sum;
        },
        apply(receiver, ...args) {
            sum += args[1][0];
            return proxy;
        },
    });
    return proxy;
}

//Function Cache
function cache(func) {
    let cache = {};
    return (...args) => {
        let arg1 = args[0];
        let arg2 = args[1];
        let cache_key = JSON.stringify(args);;
        if (cache_key in cache) {
            return cache[cache_key];
        }
        else {
            cache[cache_key] = func(arg1, arg2);
            return cache[cache_key];
        }
    }
}

//Function Composition  
function compose(f, g) {
    return function (...args) {
        return f(g(...args));
    }
}

//Function Composition 1 
const composes = (...functions) => args => functions.reduceRight((arg, fn) => fn(arg), args);

//OOP & Inheritance

//Array Helpers
Object.assign(Array.prototype, {
    square() {
        return this.map(n => n * n);
    },
    cube() {
        return this.map(n => Math.pow(n, 3));
    },
    sum() {
        return this.reduce((p, n) => p + n, 0);
    },
    average() {
        return this.reduce((p, n) => p + n, 0) / this.length;
    },
    even() {
        return this.filter(n => !(n % 2));
    },
    odd() {
        return this.filter(n => n % 2);
    }
});

//Extract Nested Object Reference
// return the nested property value if it exists,
// otherwise return undefined
Object.prototype.hash = function (string) {
    var obj = this;
    string.split(".").forEach(function (element) {
        try {
            obj = obj[element];
        }
        catch (exec) {
            obj = undefined;
        }
    });
    return obj;
}

//new with apply
function construct(Class) {
    return new (Class.bind.apply(Class, arguments))();
}

//SantaClausable Interface
function isSantaClausable(obj) {
    return ['sayHoHoHo', 'distributeGifts', 'goDownTheChimney'].every(
        methodName => typeof obj[methodName] === 'function'
    );
}


//Refereance: https://github.com/DenisSoft/Lib-JS