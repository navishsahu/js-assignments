﻿//JAVASCRIPT DATA TYPES

//Printing Array elements with Comma delimiters
function printArrayCommaDelimited() {
    var arr = ["h", "o", "l", "a"];
    for (var str in arr) {
        document.write(arr[str]);
        if (str < arr.length - 1)
            document.write(',');
    }
};
printArrayCommaDelimited();
document.write("<br>");

document.write("<br>");

//Opposite number
function oppositeNumber(number) {
    document.write(number + " : " + -number);
};
oppositeNumber(1);
document.write("<br>");
oppositeNumber(14);
document.write("<br>");
oppositeNumber(-34);
document.write("<br>");

document.write("<br>");

//Basic Mathematical Operations
function mathOperation(operand, firstValue, secondValue) {
    if (operand === '+')
        document.write(firstValue + secondValue);
    else if (operand === '-')
        document.write(firstValue - secondValue);
    else if (operand === '*')
        document.write(firstValue * secondValue);
    else if (operand === '/')
        document.write(firstValue / secondValue);
};
mathOperation('+', 4, 7);
document.write("<br>");
mathOperation('-', 15, 18);
document.write("<br>");
mathOperation('*', 5, 5);
document.write("<br>");
mathOperation('/', 49, 7);
document.write("<br>");

document.write("<br>");

//Transportation on vacation 
function rentalCarOffer(d) {
    let day = d >= 3 && d < 7 ? 20 : 0, // day discount
        week = d >= 7 ? 50 : 0; // week discount

    document.write((d * 40) - day - week);
};
rentalCarOffer(3);
document.write("<br>");
rentalCarOffer(7);
document.write("<br>");

document.write("<br>");
document.write("<br>");

//FUNCTIONS & SCOPE

//Calculating with Functions
function zero() {
    return arguments.length === 1 ? arguments[0](0) : 0;
}
function one() {
    return arguments.length === 1 ? arguments[0](1) : 1;
}
function two() {
    return arguments.length === 1 ? arguments[0](2) : 2;
}
function three() {
    return arguments.length === 1 ? arguments[0](3) : 3;
}
function four() {
    return arguments.length === 1 ? arguments[0](4) : 4;
}
function five() {
    return arguments.length === 1 ? arguments[0](5) : 5;
}
function six() {
    return arguments.length === 1 ? arguments[0](6) : 6;
}
function seven() {
    return arguments.length === 1 ? arguments[0](7) : 7;
}
function eight() {
    return arguments.length === 1 ? arguments[0](8) : 8;
}
function nine() {
    return arguments.length === 1 ? arguments[0](9) : 9;
}
function plus() {
    var val = arguments[0];
    return function (left) {
        document.write(left + val);
    }
}
function minus() {
    var val = arguments[0];
    return function (left) {
        document.write(left - val);
    }
}
function times() {
    var val = arguments[0];
    return function (left) {
        document.write(left * val);
    }
}
function divided_by() {
    var val = arguments[0];
    return function (left) {
        document.write(left / val);
    }
}
seven(times(five()));
document.write("<br>");
four(plus(nine()));
document.write("<br>");
eight(minus(three()));
document.write("<br>");
six(divided_by(two()));
document.write("<br>");

document.write("<br>");

//Get the Middle Character
const getMiddle = s => s.substr(s.length - 1 >>> 1, (~s.length & 1) + 1);

document.write(getMiddle('test'));
document.write("<br>");
document.write(getMiddle('testing'));
document.write("<br>");
document.write(getMiddle('middle'));
document.write("<br>");
document.write(getMiddle('A'));
document.write("<br>");

document.write("<br>");

//Alternate solution
function getMiddleChars(s) {
    document.write(s.length % 2 ? s.substr(s.length / 2, 1) : s.substr((s.length / 2) - 1, 2));
}
getMiddleChars('middle');
document.write("<br>");

document.write("<br>");

//Partition On
function partitionOn(array) {
    var even = [], odd = [];
    for (var i = 0; i < array.length; i++) {

        (array[i] % 2 === 0) ? even.push(array[i]) : odd.push(array[i]);
        
    };
    document.write([odd, even]);
}
partitionOn([1, 2, 3, 4, 5, 6]);
document.write("<br>");

document.write("<br>");

//Word Count
function countWords(str) {
    document.write(str.trim().split(" ").length);
}
countWords("Hello");
document.write("<br>");
countWords("Hello, World!");
document.write("<br>");
countWords("No results for search term `s`");
document.write("<br>");
countWords(" Hello");
document.write("<br>");

document.write("<br>");
document.write("<br>");

//DYNAMIC SCOPE

//Prefill an Array
function prefill(n, v) {
    try {
        if (isNaN(n))
            throw new TypeError(n + " is invalid");

        var a = [];
        for (let i = 0; i < n; i++) {
            a.push(v);
        }
        return a;
    } catch (e) {
        return e.message;
    }
}
document.write(prefill(3, 1));
document.write("<br>");
document.write(prefill(2, "abc"));
document.write("<br>");
document.write(prefill("1", 1));
document.write("<br>");
document.write(prefill(3, prefill(2, "2d"))); 
document.write("<br>");
document.write(prefill("xyz", 1));
document.write("<br>");

document.write("<br>");

//Closures and Scopes
function createFunctions(n) {
    var callbacks = [];
    function handle(j) {
        return function () {
            return j;
        }
    };
    for (var i = 0; i < n; i++) {
        callbacks.push(handle(i));
    }
    return callbacks;
}
var callbacks = createFunctions(5); // create an array, containing 5 functions

document.write(callbacks[0]()); // must return 0
document.write("<br>");
document.write(callbacks[3]()); // must return 3
document.write("<br>");

document.write("<br>");

//Can you keep a secret?
function createSecretHolder(secret) {
    var secret = secret;
    this.getSecret = function () {
        document.write(secret);
    }
    this.setSecret = function (newSecret) {
        secret = newSecret;
        return secret;
    }
}
var obj = new createSecretHolder(5);
obj.getSecret();
document.write("<br>");
obj.setSecret(2);
obj.getSecret();
document.write("<br>");

document.write("<br>");

//A function within a function
function always(n) {
    return function (){
        document.write(n);
    }
}
var three = always(3);
three();
document.write("<br>");

document.write("<br>");

//OBJECTS and ARRAYS

//Using closures to share class state
var Cat = (function () {
    var count = 0, sum = 0;
    function Cat(name, weight) {
        if (!name || !weight)
            throw new Error("not valid argument");
        count++;
        sum += weight;
        Object.defineProperty(this, "weight", {
            get: function () {
                return weight;
            },
            set: function (value) {
                weight = value;
            }
        });
    }
    Cat.averageWeight = function () {
        return sum/count;
    }
    return Cat;
}());

garfield = new Cat('garfield', 25);
Cat.averageWeight; // 25
document.write("<br>");
felix = new Cat('felix', 15);
Cat.averageWeight;   // now 20
document.write("<br>");

document.write("<br>");

//A Chain adding function
function add(n) {
    var sum = n;
    const proxy = new Proxy(function a() { }, {
        get(obj, key) {
            return () => sum;
        },
        apply(receiver, ...args) {
            sum += args[1][0];
            return proxy;
        },
    });
    return proxy
}

document.write(add(1)(2)(3)); // 6
document.write("<br>");
document.write(add(1)(2)(3)(4)); // 10
document.write("<br>");
document.write(add(1)(2)(3)(4)(5)); // 15
document.write("<br>");
document.write(add(1)); // 1
document.write("<br>");

var addTwo = add(2);
document.write(addTwo); // 2
document.write("<br>");
document.write(addTwo + 5); // 7
document.write("<br>");
document.write(addTwo(3)); // 5
document.write("<br>");
document.write(addTwo(3)(5)); // 10
document.write("<br>");

document.write("<br>");

//Function Cache
const complexFunction = function (arg1, arg2) { return arg1 + arg2; };
function cache(func) {
    let cache = {};
    return (...args) => {
        let arg1 = args[0];
        let arg2 = args[1];
        // Use JSON.stringify on the arguments to create a cache key
        let cache_key = JSON.stringify(args);;
        // If cache key is present in cache, retrieve the value of the cache key
        if (cache_key in cache) {
            document.write('Fetching from cache');
            document.write("<br>");
            return cache[cache_key];
        }
        // Otherwise, calculate the result of the complex function by calling it
        else {
            document.write('Calculating result');
            document.write("<br>");
            cache[cache_key] = func(arg1, arg2);
            return cache[cache_key];
        }
    }
}
const cachedFunction = cache(complexFunction);
document.write(cachedFunction('foo', 'bar')); // complex function should be executed
document.write("<br>");
document.write(cachedFunction('foo', 'bar')); // complex function should not be invoked again, instead the cached result should be returned
document.write("<br>");
document.write(cachedFunction('foo', 'baz')); // should be executed, because the method wasn't invoked before with these arguments
document.write("<br>");

document.write("<br>");

//Function Composition  
function compose(f, g) {
    return function (...args) {
        return f(g(...args));
    }
}

add1 = function (a) { return a + 1 }
id = function (a) { return a }

document.write(compose(add1, id)(0));          //1
document.write("<br>");

document.write("<br>");

//Function Composition 1 
const composes = (...functions) => args => functions.reduceRight((arg, fn) => fn(arg), args);

const addOne = (a) => a + 1
const multTwo = (b) => b * 2

document.write(composes(addOne, multTwo, addOne, addOne)(2));   //9
document.write("<br>");

document.write("<br>");

//OOP & Inheritance

//Array Helpers
class extendedArray extends Array {
    square() {
        document.write(this.map(x => x ** 2));
    }
    cube() {
        document.write(this.map(x => x ** 3));
    }
    average() {
        var avg = 0;
        this.forEach(function (n) { avg += n });
        document.write(avg/this.length);
    }
    sum() {
        var sum = 0;
        this.forEach(function (n) { sum += n });
        document.write(sum);
    }
    even() {
        document.write(this.filter((a, i) => i % 2 === 1));
    }
    odd() {
        document.write(this.filter((a, i) => i % 2 === 0));
    }
}
var numbers = new extendedArray(1, 2, 3, 4, 5);
numbers.square();
document.write("<br>");
numbers.cube();
document.write("<br>");
numbers.average();
document.write("<br>");
numbers.sum();
document.write("<br>");
numbers.even();
document.write("<br>");
numbers.odd();
document.write("<br>");

document.write("<br>");

//Extract Nested Object Reference
var obj = {
    person: {
        name: 'joe',
        history: {
            hometown: 'bratislava',
            bio: {
                funFact: 'I like fishing.'
            }
        }
    }
};
Object.prototype.hash = function (propertyName) {
    var parts = propertyName.split("."),
        length = parts.length,
        i,
        property = this.obj || this;

    for (i = 0; i < length; i++) {
        if ((typeof property == "object") || (!typeof property == "undefined")) {
            if (!property.hasOwnProperty.call(parts[i]))
                property = property[parts[i]];
        }
    }
    document.write(JSON.stringify(property));
}
obj.hash('person.name'); // 'joe'
document.write("<br>");
obj.hash('person.history.bio'); // { funFact: 'I like fishing.' }
document.write("<br>");
obj.hash('person.history.homeStreet'); // undefined
document.write("<br>");
obj.hash('person.animal.pet.needNoseAntEater'); // undefined
document.write("<br>");

document.write("<br>");

//new with apply
function Greeting(name) {
    this.name = name;
}

Greeting.prototype.sayHello = function () {
    return "Hello " + this.name;
};


Greeting.prototype.sayBye = function () {
    return "Bye " + this.name;
};

var greeting = new Greeting('John');

document.write(greeting.sayHello());
document.write("<br>");
document.write(greeting.sayBye());
document.write("<br>");

function construct() {
    return new (Greeting.bind.apply(Greeting, arguments));
}

var greeting = construct(Greeting, 'John');

document.write(greeting.sayHello());
document.write("<br>");
document.write(greeting.sayBye());
document.write("<br>");

function factory() {
    return {
        createGreeting() {
            return construct(Greeting, arguments);
        }
    }
}

document.write("<br>");

//SantaClausable Interface
var santa = {
    sayHoHoHo: function () { console.log('Ho Ho Ho!') },
    distributeGifts: function () { console.log('Gifts for all!'); },
    goDownTheChimney: function () { console.log('*whoosh*'); }
};

var notSanta = {
    sayHoHoHo: function () { console.log('Oink Oink!') }
    // no distributeGifts() and no goDownTheChimney()
};

const isSantaClausable = obj =>
    ['sayHoHoHo', 'distributeGifts', 'goDownTheChimney'].every(
        methodName => typeof obj[methodName] === 'function'
    );

document.write(isSantaClausable(santa)); // must return TRUE
document.write("<br>");
document.write(isSantaClausable(notSanta)); // must return FALSE