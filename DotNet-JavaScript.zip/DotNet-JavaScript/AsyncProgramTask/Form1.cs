﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace AsyncProgramTask
{
    public partial class frmAsyncTask : Form
    {
        private string[] files;
        CancellationTokenSource tokenSource = new CancellationTokenSource();
        Task task = null;
        public frmAsyncTask()
        {
            InitializeComponent();
        }

        private void btnFolder_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                linkLabel.Text = Path.GetDirectoryName(openFileDialog.FileName);
                files = openFileDialog.FileNames;
            }
            
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                CancellationToken token = tokenSource.Token;
                if (files == null)
                {
                    SetLableMessageForUI("Error", "Please select the folder");
                    return;
                }
                
                progressBar.Maximum = files.Count();
                progressBar.Show();
                string appendText = richTextBox.Text;

                task = Task.Factory.StartNew(() =>
                {
                    Parallel.ForEach(files, new ParallelOptions { MaxDegreeOfParallelism = 4 }, (file) =>
                    {
                        if (token.IsCancellationRequested)
                        {
                            token.ThrowIfCancellationRequested();
                        }
                        progressBar.BeginInvoke((Action)(() => progressBar.PerformStep()));
                        using (StreamWriter sw = new StreamWriter(file, true))
                        {
                            sw.WriteLineAsync(Environment.NewLine);
                            sw.WriteLineAsync(appendText);
                        }
                        Thread.Sleep(1000);/*
                        while (!token.IsCancellationRequested)
                        {
                            progressBar.BeginInvoke((Action)(() => progressBar.PerformStep()));
                            using (StreamWriter sw = new StreamWriter(file, true))
                            {
                                sw.WriteLineAsync(Environment.NewLine);
                                sw.WriteLineAsync(appendText);
                            }
                            Thread.Sleep(1000);
                        }
                        if (token.IsCancellationRequested)
                        {
                            token.ThrowIfCancellationRequested();
                        }*/
                    });
                }, token);
                
                SetLableMessageForUI("Info", "Task Completed");
            }
            catch (Exception ex)
            {
                SetLableMessageForUI("Error", ex.Message);
            }
        }

        private void SetLableMessageForUI(string code, string message)
        {
            switch (code)
            {
                case "Error":
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    break;
                case "Info":
                    lblMessage.ForeColor = System.Drawing.Color.Blue;
                    break;
            }
            
            lblMessage.Text = message;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                tokenSource.Cancel();
                task.Wait();
            }
            catch (AggregateException)
            {
                SetLableMessageForUI("Error", "Thread Canceled");
            }
            catch (OperationCanceledException)
            {
                SetLableMessageForUI("Error", "Thread Canceled");
            }
        }
    }
}
