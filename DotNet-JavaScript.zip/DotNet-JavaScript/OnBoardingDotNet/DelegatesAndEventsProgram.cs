﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnBoardingDotNet
{
    public class DelegatesAndEventsProgram
    {
        //001: OrderShipment class. Processes 
        //the order placed by the customers
        public class OrderShipment 
        {
            //001_1: Declare the Multi-cast delegate. 
            //Note the return type should be void
            public delegate void
                OrderProcessingMethods(int OrderId,
                int CustomerId);

            //001_2: Implement the Order Processing Functions
            //Processing Function 1
            public void GetShoppingCartItems(int OrderId,
                int CustomerId)
            {
                Console.WriteLine("(1) GetShoppingCartItems");
                Console.WriteLine("========================");
                Console.WriteLine("All shopping Cart Items are Collected.");
                Console.WriteLine("Formed a Order with supplied OrderId");
                Console.WriteLine("_________________________________________________________________");
            }

            //Processing Function 2
            public void CalculateOrderPrice(int OrderId,
                int Customerid)
            {
                Console.WriteLine("(2) CalculateOrderPrice");
                Console.WriteLine("=======================");
                Console.WriteLine("Price of each products collected from the shopping cart summed up");
                Console.WriteLine("Order Price calculated");
                Console.WriteLine("_________________________________________________________________");
            }

            //Processing Function 3
            public void CalculateDiscount(int OrderId,
                int Customerid)
            {
                Console.WriteLine("(3) CalculateDiscount");
                Console.WriteLine("=====================");
                Console.WriteLine("Get the Discount amount for the Season");
                Console.WriteLine("Reduce Order Price");
                Console.WriteLine("_________________________________________________________________");
            }

            //Processing Function 4
            public void GetOrderConfirmation(int OrderId,
                int Customerid)
            {
                Console.WriteLine("(4) GetOrderConfirmation");
                Console.WriteLine("========================");
                Console.WriteLine("Order confirmation screen shown to the User");
                Console.WriteLine("Order Confirmed");
                Console.WriteLine("_________________________________________________________________");
            }

            //001_3: Takes a multicase delegate and performs 
            //business logic            
            public void ProcessOrderShipment(
                OrderProcessingMethods ProcessToFollow,
                int Orderid, int Customerid)
            {
                ProcessToFollow(Orderid, Customerid);
            }

        }
    }
}
