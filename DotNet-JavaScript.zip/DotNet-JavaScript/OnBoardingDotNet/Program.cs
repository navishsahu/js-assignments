﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Dynamic;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Reflection.Metadata;
using System.Text.RegularExpressions;

namespace OnBoardingDotNet
{
    public class Program
    {
        public static void Main(string[] args)
        {
            #region Exception Handling
            //TASK 1
            string[] list = new string[5];
            list[0] = "Sunday007";
            list[1] = "Monday";
            list[2] = "Tuesday";
            list[3] = "Wednesday";
            list[4] = "Thursday";

            try
            {
                PrintDays(list);

                Console.ReadLine();
            }
            catch (CustomException ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            catch (OutOfMemoryException ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

            //TASK 2
            void ReadFileContent()
            {
                try
                {
                    using (var file = new StreamReader(@"D:\myfolder\myfile.txt"))
                    {
                        char[] buffer = new char[10];
                        file.ReadBlock(buffer, 0, buffer.Length);
                        file.Close();
                    }
                }
                catch (FileNotFoundException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadLine();
                }
                catch (DirectoryNotFoundException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadLine();
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadLine();
                }
                catch (ObjectDisposedException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadLine();
                }
            }
            #endregion

            #region Delegates & Events

            #endregion

            #region Collections & Generics
            List<Student> studentList = new List<Student>(Student.GetSampleData());
            //FIND and PRINT
            studentList.Find(a => a.RegistrationNumber == 1000).print();
            //ORDER and PRINT
            var orderedList = studentList.OrderBy(s => s.TotalScore).ToList();
            orderedList.ForEach(s => s.print());
            Console.ReadLine();
            #endregion

            #region LINQ
            IList<Employees> employees = new List<Employees>();
            employees.Add(new Employees { EmployeeId = 1, Name = "Ravi", Gender = "Male", Age = 28, Salary = 1900007, DepartmentId = 1, ManagerId = 8 });
            employees.Add(new Employees { EmployeeId = 2, Name = "Amit", Gender = "Male", Age = 27, Salary = 1800012, DepartmentId = 2, ManagerId = 9 });
            employees.Add(new Employees { EmployeeId = 3, Name = "Uma", Gender = "Male", Age = 33, Salary = 1100760, DepartmentId = 3, ManagerId = 8 });
            employees.Add(new Employees { EmployeeId = 4, Name = "Asha", Gender = "Female", Age = 29, Salary = 1800000, DepartmentId = 4, ManagerId = 12 });
            employees.Add(new Employees { EmployeeId = 5, Name = "Ankit", Gender = "Male", Age = 31, Salary = 2000000, DepartmentId = 5, ManagerId = 8 });
            employees.Add(new Employees { EmployeeId = 6, Name = "Gaurav", Gender = "Male", Age = 29, Salary = 1740000, DepartmentId = 1, ManagerId = 9 });
            employees.Add(new Employees { EmployeeId = 7, Name = "Swati", Gender = "Female", Age = 30, Salary = 1700091, DepartmentId = 2, ManagerId = 8 });
            employees.Add(new Employees { EmployeeId = 10, Name = "Nayeem", Gender = "Male", Age = 29, Salary = 1300066, DepartmentId = 5, ManagerId = 9 });
            employees.Add(new Employees { EmployeeId = 8, Name = "Swagat", Gender = "Male", Age = 31, Salary = 3800780, DepartmentId = 3, ManagerId = 11 });
            employees.Add(new Employees { EmployeeId = 9, Name = "Ali", Gender = "Male", Age = 32, Salary = 4500099, DepartmentId = 4, ManagerId = 11 });
            employees.Add(new Employees { EmployeeId = 11, Name = "Neeraj", Gender = "Male", Age = 35, Salary = 5400099, DepartmentId = 4 });
            employees.Add(new Employees { EmployeeId = 12, Name = "Navish", Gender = "Male", Age = 35, Salary = 5400099, DepartmentId = 4 });

            IList<Department> departments = new List<Department>();
            departments.Add(new Department { DepartmentId = 1, Name = "IT" });
            departments.Add(new Department { DepartmentId = 2, Name = "FINANCE" });
            departments.Add(new Department { DepartmentId = 3, Name = "INFRASTUCTURE" });
            departments.Add(new Department { DepartmentId = 4, Name = "AUDIT" });
            departments.Add(new Department { DepartmentId = 5, Name = "SERVICES" });

            //PLINQ
            var oddSalaries = employees.AsParallel().Where(e => e.Salary % 2 == 1).Select(e => e);

            foreach (var item in oddSalaries)
                Console.WriteLine(item.Name + " has odd salary of " + item.Salary);

            //LINQ GROUP BY JOIN
            var groupByDept = employees.GroupBy(e => e.DepartmentId).ToList();

            foreach (var item in groupByDept)
            {
                foreach (var i in item.Join(departments, e => e.DepartmentId, d => d.DepartmentId, (e, d) => new { Name = e.Name, Dept = d.Name }))
                {
                    Console.WriteLine(i.Name + " is in " + i.Dept + " department");
                }
            }

            //HIGHEST SALARY BY DEPERTMENT
            var highSalByDept = employees.GroupBy(e => e.DepartmentId);

            foreach (var item in highSalByDept)
            {
                foreach (var i in item.Join(departments, e => e.DepartmentId, d => d.DepartmentId, (e, d) => new { Salary = e.Salary, Dept = d.Name }).OrderBy(e => e.Salary).TakeLast(1))
                {
                    Console.WriteLine(i.Dept + " has highest salary of " + i.Salary);
                }
            }

            //SALARY HIKE BY GENDER
            foreach (var item in employees)
            {
                Console.WriteLine("Incremented salary of " + item.Name + " is " + (item.Gender.Equals("MALE") ? item.Salary += 1000 : item.Gender.Equals("FEMALE") ? item.Salary += 1500 : item.Salary));
            }

            //SELF JOIN
            foreach (var item in employees.Join(employees, e => e.EmployeeId, m => m.ManagerId, (e, m) => new { e.ManagerId, e.Name }).Where(e => e.ManagerId != null).Distinct())
            {
                Console.WriteLine("Manager Id is: " + item.ManagerId + " Manager Name is: " + item.Name);
            }

            //DEEP COPY
            foreach (var item in employees.Where(e => e.ManagerId == 11))
            {
                var newSalary = item.Salary + (item.Salary * 10 / 100);
                Console.WriteLine("Employee Name: " + item.Name + " has new salary of: " + newSalary);
                newSalary = 0;
            }
            Console.ReadLine();
            #endregion

            #region Memory Managment
            MyClass myClass;
            using (myClass = new MyClass())
            {
                myClass.MyInteger = 88;
                Console.WriteLine(myClass.MyInteger);
            }

            try
            {
                myClass = new MyClass();
            }
            finally
            {
                Console.WriteLine("finally...");
                myClass.Dispose();
            }
            Console.ReadLine();
            #endregion

            #region C# New Features
            Employee employee = new Employee();
            var name = employee.GetFullName(employee);
            //VALUETUPLE METHOD
            Console.WriteLine(name.Item1 + " " + name.Item2 + " " + name.Item3);

            //EXPRESSION BODIED METHODS
            Console.WriteLine(employee);
            employee.DisplayName();

            dynamic employee1 = new ExpandoObject();
            employee1.FirstName = "Navish";
            employee1.LastName = "Sahu";
            //EXPANDOOBJECT
            Console.WriteLine(employee1.FirstName + " " + employee1.LastName);
            Console.ReadLine();
            #endregion
        }

        private static void PrintDays(string[] list)
        {
            Regex regex = new Regex("^[a-zA-Z]+$");
            for (int i = 0; i <= 5; i++)
            {
                if (!regex.IsMatch(list[i].ToString()))
                    throw new CustomException(list[i].ToString());
                
                Console.WriteLine(list[i].ToString());
            }
        }
    }

    public class Employee
    {
        public string FirstName { get; set; } = "Navish";
        public string MiddleName { get; set; }
        public string LastName { get; set; } = "Sahu";
        public string Email { get; set; }
        private string salary { get; set; }

        public string Salary
        {
            get => salary;
            set => this.salary = value ?? "0.00";
        }

        public ValueTuple<object, object, object> GetFullName(Employee employee)
        {
            return (employee.FirstName, employee.MiddleName, employee.LastName);
        }

        public override string ToString() => $"{FirstName} {MiddleName} {LastName}".Trim();
        public void DisplayName() => Console.WriteLine(ToString());

        ~Employee() => Console.WriteLine(ToString() + " Finalized");
    }

    public class MyClass : IDisposable
    {
        public int MyInteger { get; set; }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    Console.WriteLine("Disposing... " + typeof(MyClass).Name);
                    Console.ReadLine();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~MyClass() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion

    }

    public class Employees
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public decimal Salary { get; set; }
        public int DepartmentId { get; set; }
        public int? ManagerId { get; set; }
    }

    public class Department
    {
        public int DepartmentId { get; set; }
        public string Name { get; set; }
    }

    public class Student
    {
        public int RegistrationNumber { get; set; }
        public string Name { get; set; }
        public int PhysicsScore { get; set; }
        public int ChemistryScore { get; set; }
        public int MathScore { get; set; }
        public int BiologyScore { get; set; }
        public int TotalScore { get; set; }

        public Student(string name, int registrationNumber, int physicsScore, int chemistryScore, int mathScore,
            int biologyScore)
        {
            this.Name = name;
            this.RegistrationNumber = registrationNumber;
            this.PhysicsScore = physicsScore;
            this.ChemistryScore = chemistryScore;
            this.MathScore = mathScore;
            this.BiologyScore = biologyScore;
            this.TotalScore = this.MathScore + this.PhysicsScore + this.ChemistryScore + this.BiologyScore;
        }

        public void print()
        {
            int totalScore = MathScore + PhysicsScore + ChemistryScore + BiologyScore;
            Console.WriteLine("Name:{0};Reg Number:{1};Maths:{2};Phy:{3};Chem:{4};Bio:{5};Total:{6}",
               Name,
               RegistrationNumber,
               MathScore,
               PhysicsScore,
               ChemistryScore,
               BiologyScore,
               totalScore
            );
        }

        public static Student[] GetSampleData()
        {
            Student[] arr = new Student[]
            {
                new Student("zz", 1025, 65, 58, 93, 76),
                new Student("yy", 1024, 66, 60, 91, 84),
                new Student("xx", 1023, 67, 62, 90, 77),
                new Student("ww", 1022, 68, 64, 89, 83),
                new Student("vv", 1021, 69, 66, 87, 82),
                new Student("uu", 1020, 70, 68, 87, 78),
                new Student("tt", 1019, 71, 70, 85, 81),
                new Student("ss", 1018, 72, 72, 84, 76),
                new Student("rr", 1017, 73, 74, 83, 80),
                new Student("qq", 1016, 74, 76, 81, 79),
                new Student("pp", 1015, 75, 78, 81, 78),
                new Student("oo", 1014, 76, 80, 79, 78),
                new Student("nn", 1013, 77, 82, 78, 80),
                new Student("mm", 1012, 78, 84, 77, 69),
                new Student("ll", 1011, 79, 86, 75, 70),
                new Student("kk", 1010, 80, 88, 75, 82),
                new Student("JJ", 1009, 81, 90, 73, 71),
                new Student("II", 1008, 82, 92, 72, 84),
                new Student("HH", 1007, 83, 94, 71, 72),
                new Student("GG", 1006, 84, 96, 69, 73),
                new Student("FF", 1005, 85, 98, 69, 86),
                new Student("EE", 1004, 86, 70, 67, 74),
                new Student("DD", 1003, 87, 71, 66, 88),
                new Student("CC", 1002, 88, 72, 65, 75),
                new Student("BB", 1001, 89, 73, 63, 90),
                new Student("AA", 1000, 90, 74, 60, 92)
            };
            return arr;
        }
    }

    [Serializable]
    public class CustomException : Exception
    {
        public CustomException() { }

        public CustomException(string days)
            : base(String.Format("Invalid Day: {0}", days)) { }
    }

    public class MyDivisionClass
    {
        public int Divide(int a, int b)
        {
            return a / b;
        }
    }

    public class MyService
    {
        public string ReturnAorB(int? value)
        {
            if (value == null)
                throw new ArgumentNullException("Value can't null");

            if (value < 1)
                throw new ArgumentException("Value can't be 0 or <0");

            if (value < 51)
                return "A";

            return "B";
        }
    }

    public class MyNewService
    {
        MyService _myService;
        public MyNewService(MyService myService)
        {
            _myService = myService;
        }

        public string WhatItReturns(int? value)
        {
            return _myService.ReturnAorB(value);
        }
    }

}
