// Identify and Refactor the below code using design principles
using System;
using System.Collections.Generic;

interface ICustomer
{
    void AddCustomer(Customer obj);
    int Count { get; }
}

public class SpecialCustomers:ICustomer
{
    List<Customer> listCustomer;
    public SpecialCustomers()
    {
        listCustomer = new List<Customer>();
    }
 
    public virtual void AddCustomer(Customer obj)
    {
        listCustomer.Add(obj);
    }
 
    public int Count
    {
        get
        {
            return listCustomer.Count;
        }
    }
}

public class TopNCustomers:SpecialCustomers
{
    private int maxCount = 5;
 
    public override void AddCustomer(Customer obj)
    {
        if (Count < maxCount)
        {
            AddCustomer(obj);
        }
        else
        {
            throw new Exception("Only " + maxCount + " customers can be added.");
        }
    }
}

public class Program
{
	public static void Main()
	{
		SpecialCustomers sc = null;
		sc = new TopNCustomers();
        for (int i = 0; i < 10; i++)
		{
			Customer obj = new Customer();
			sc.AddCustomer(obj);
		}
	}
}