// Identify and Refactor the below code using design principles
public class TaxCalculator
{
    public decimal CalculateTax(decimal amount,string country)
    {
        decimal taxAmount = 0;
        switch(country)
        {
            case "USA":
                USATaxCalulator americanTax = new USATaxCalulator();
                americanTax.Calculate(amount, country);
                break;
            case "UK":
                UKTaxCalulator englandTax = new UKTaxCalulator();
                englandTax.Calculate(amount, country);
                break;
            case "IN":
                INTaxCalulator indianTax = new INTaxCalulator();
                indianTax.Calculate(amount, country);
                break;
        }
        return taxAmount;
    }
}

interface ICalculator
{
    decimal Calculate(decimal amount, string country);
}

public class USATaxCalulator : ICalculator
{
    private decimal taxAmount;

    public decimal Calculate(decimal amount, string country)
    {
        return taxAmount;
    }
}

public class UKTaxCalulator : ICalculator
{
    private decimal taxAmount;

    public decimal Calculate(decimal amount, string country)
    {
        return taxAmount;
    }
}

public class INTaxCalulator : ICalculator
{
    private decimal taxAmount;

    public decimal Calculate(decimal amount, string country)
    {
        return taxAmount;
    }
}