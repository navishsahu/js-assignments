// Identify and Refactor the below code using design principles
using System.Collections.Generic;
using System.Text;
using System.Data.Entity;
using System.Linq;

public class CustomerHelper
{
    NorthwindEntities db;

    public CustomerHelper()
    {
        db = new NorthwindEntities();
    }
 
    public List<Customer> GetAllCustomers()
    {
        return db.Customers.ToList();
    }
 
    public Customer GetCustomerByID(string customerid)
    {
        return db.Customers.Find(c => c.CustomerID == customerid);
    }
 
    public string ExportCustomerData()
    {
        List<Customer> data = GetAllCustomers();
        StringBuilder sb = new StringBuilder();
        foreach(Customer item in data)
        {
            sb.Append(item.CustomerID);
            sb.Append(",");
            sb.Append(item.CompanyName);
            sb.Append(",");
            sb.Append(item.ContactName);
            sb.Append(",");
            sb.AppendLine(item.Country);
        }
        return sb.ToString();
    }
}

internal class NorthwindEntities
{
    public List<Customer> Customers { get; internal set; }
}

public class Customer
{
    public string CustomerID { get; internal set; }
    public string CompanyName { get; internal set; }
    public string ContactName { get; internal set; }
    public string Country { get; internal set; }
}
