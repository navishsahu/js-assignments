// Identify and Refactor the below code using design principles
using System;

interface IProcessor
{
    void ProcessOrder();
}

public abstract class OrderProcessor
{
    public abstract bool ValidatePaymentInfo();
    public abstract bool ValidateShippingAddress();
}
public class OnlineOrder:OrderProcessor,IProcessor
{
 
    public override bool ValidatePaymentInfo()
    {
        return true;
    }
 
    public override bool ValidateShippingAddress()
    {
        return true;
    }
 
    public void ProcessOrder()
    {
        //place order here if everything is ok.
    }
}
 
public class CashOnDeliveryOrder:OrderProcessor,IProcessor
{
    public override bool ValidatePaymentInfo()
    {
        throw new NotImplementedException();
    }
 
    public override bool ValidateShippingAddress()
    {
        throw new NotImplementedException();
    }
 
    public void ProcessOrder()
    {
        //place order here if everything is ok.
    }
}