using NUnit.Framework;
using OnBoardingDotNet;
using System;

namespace Tests
{
    public class UnitTests
    {
        MyDivisionClass myDClass;
        MyService myService;
        MyNewService myNewService;

        [SetUp]
        public void Setup()
        {
            myDClass = new MyDivisionClass();
            myService = new MyService();
            myNewService = new MyNewService(myService);
        }

        [Test]
        public void Divided_By_Zero_Exception()
        {
            //Arrange
            int a = 10, b = 0;

            //Act
            
            //Assert
            Assert.Throws<DivideByZeroException>(() => myDClass.Divide(a, b));
        }

        [Test]
        public void Dividend_Greater_Than_Divisor_And_Quotient_Is_Positive()
        {
            //Arrange
            int a = 10, b = 2;

            //Act
            int result = myDClass.Divide(a, b);

            //Assert
            Assert.Multiple(() =>
            {
                Assert.NotZero(result);
                Assert.Positive(result);
                Assert.AreEqual(result, 5);
            });

        }

        [Test]
        public void Dividend_Less_Than_Divisor_And_Quotient_Is_Zero()
        {
            //Arrange
            int a = 2, b = 10;

            //Act
            int result = myDClass.Divide(a, b);

            //Assert
            Assert.Zero(result);
        }

        [Test]
        public void Dividend_Equal_To_Divisor_And_Quotient_Is_One()
        {
            //Arrange
            int a = 10, b = 10;

            //Act
            int result = myDClass.Divide(a, b);

            //Assert
            Assert.Multiple(() =>
            {
                Assert.NotZero(result);
                Assert.Positive(result);
                Assert.AreEqual(result, 1);
            });
        }

        [Test]
        public void MyService_Throws_ArgumentNull_Exception()
        {
            //Arrange

            //Act

            //Assert
            Assert.Throws<ArgumentNullException>(() => myService.ReturnAorB(null), "Value can't null");
        }

        [Test]
        public void MyService_Throws_InvalidArgument_Exception()
        {
            //Arrange

            //Act

            //Assert
            Assert.Multiple(() =>
            {
                Assert.Throws<ArgumentException>(() => myService.ReturnAorB(0), "Value can't be 0 or <0");
                Assert.Throws<ArgumentException>(() => myService.ReturnAorB(-1), "Value can't be 0 or <0");
            });
        }

        [Test]
        public void MyService_ReturnsB_WhenValue_GreaterThan_50()
        {
            //Arrange

            //Act
            string value = myService.ReturnAorB(51);

            //Assert
            Assert.AreEqual(value, "B");
        }

        [Test]
        public void MyService_ReturnsA_WhenValue_LessThan_50()
        {
            //Arrange

            //Act
            string value = myService.ReturnAorB(50);

            //Assert
            Assert.AreEqual(value, "A");
        }

        [Test]
        public void MyNewService_Throws_ArgumentNull_Exception()
        {
            //Arrange

            //Act

            //Assert
            Assert.Throws<ArgumentNullException>(() => myNewService.WhatItReturns(null), "Value can't null");
        }

        [Test]
        public void MyNewService_Throws_InvalidArgument_Exception()
        {
            //Arrange

            //Act

            //Assert
            Assert.Multiple(() =>
            {
                Assert.Throws<ArgumentException>(() => myNewService.WhatItReturns(0), "Value can't be 0 or <0");
                Assert.Throws<ArgumentException>(() => myNewService.WhatItReturns(-1), "Value can't be 0 or <0");
            });
        }

        [Test]
        public void MyNewService_ReturnsB_WhenValue_GreaterThan_50()
        {
            //Arrange

            //Act
            string value = myNewService.WhatItReturns(51);

            //Assert
            Assert.AreEqual(value, "B");
        }

        [Test]
        public void MyNewService_ReturnsA_WhenValue_LessThan_50()
        {
            //Arrange

            //Act
            string value = myNewService.WhatItReturns(50);

            //Assert
            Assert.AreEqual(value, "A");
        }
    }
}